# Simple OpenGL obj viewer

## Requirements

* GLEW
* GLFW3

## Build

Edit `Makefile`, then

    $ make

## Run

Copy .obj and .mtl to this directory, then,

    $ ./viewer input.obj

## TODo

* [ ] Materials & textures
* [ ] Shapes
