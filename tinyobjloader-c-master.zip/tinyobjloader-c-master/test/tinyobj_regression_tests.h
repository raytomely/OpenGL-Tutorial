#ifndef TINYOBJ_REGRESSION_TESTS
#define TINYOBJ_REGRESSION_TESTS

void test_tinyobj_crlf_string(void);
void test_tinyobj_negative_exponent(void);

#endif
