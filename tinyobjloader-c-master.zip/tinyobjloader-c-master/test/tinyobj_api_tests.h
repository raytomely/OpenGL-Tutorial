#ifndef TINYOBJ_API_TESTS
#define TINYOBJ_API_TESTS

void test_tinyobj_attrib_init(void);
void test_tinyobj_parse_mtl_file(void);
void test_tinyobj_parse_mtl_file_with_searchpath(void);
void test_tinyobj_parse_obj(void);

#endif
